CREATE TABLE [Load AU Suburb] (
    [suburb] nvarchar(255),
    [city] nvarchar(255),
    [state] nvarchar(255),
    [state_code] nvarchar(255),
    [lat] float,
    [lon] float
);

CREATE TABLE [Load AU Crimes] (
    [State] nvarchar(255),
    [suburb] nvarchar(255),
    [Postcode] float,
    [Offence category] nvarchar(255),
    [Offence subcategory] nvarchar(255),
    [Recorded Incidents] float
);

CREATE TABLE [Load nsw House Value] (
    [state_code] nvarchar(255),
    [Suburb] nvarchar(255),
    [Postcode] float,
    [HouseValue] float
);

CREATE TABLE [Load SA house value data] (
    [state_code] nvarchar(255),
    [Suburb] nvarchar(255),
    [HouseValue] float
);

CREATE TABLE [Load VIC House value] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [HouseValue] float
);

CREATE TABLE [Load the AU house value staging table] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [houseValue] float,
    [postcode] float
);

CREATE TABLE [Load NSW Rental value] (
    [state_code] nvarchar(255),
    [Suburb] nvarchar(255),
    [RentalHouseType] nvarchar(255),
    [RentalAmount] float
);

CREATE TABLE [Load SA Rental data] (
    [state_code] nvarchar(255),
    [Suburb] nvarchar(255),
    [RentalHouseType] nvarchar(255),
    [RentalAmount] float
);

CREATE TABLE [Load VIC Rental value] (
    [state_code] nvarchar(255),
    [Suburb] nvarchar(255),
    [RentalHouseType] nvarchar(255),
    [RentalAmount] float
);

CREATE TABLE [Load to Stg AU Rental value table] (
    [state_code] nvarchar(255),
    [Suburb] nvarchar(255),
    [RentalHouseType] nvarchar(255),
    [RentalAmount] float
);

CREATE TABLE [Load NSW Transport Table] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [stop_name] nvarchar(255),
    [mode] nvarchar(255),
    [stop_lat] float,
    [stop_long] float
);

CREATE TABLE [Load SA transport data] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [stop_name] nvarchar(255),
    [mode] nvarchar(255),
    [stop_lat] float,
    [stop_lon] float
);

CREATE TABLE [Load VIC Transport data] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [stop_name] nvarchar(255),
    [mode] nvarchar(255),
    [stop_lat] float,
    [stop_lon] float
);

CREATE TABLE [Load the Stg Transport Table] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [mode] nvarchar(255),
    [stop_name] nvarchar(255),
    [stop_lat] float,
    [stop_lon] float
)

CREATE TABLE [Load to Load_NSW_School_Value] (
    [state_code] nvarchar(255),
    [town_suburb] nvarchar(255),
    [postcode] float,
    [school_code] float,
    [school_name] nvarchar(255),
    [SchoolType] nvarchar(255),
    [address] nvarchar(255)
);

CREATE TABLE [Load to Load_VIC_School_Value] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [Postal_Postcode] float,
    [SchoolCode] float,
    [school_name] nvarchar(255),
    [SchoolType] nvarchar(255),
    [Address] nvarchar(255)
);

CREATE TABLE [load to Load_SA_School_Value] (
    [state_code] nvarchar(255),
    [suburb] nvarchar(255),
    [Post Code] float,
    [SchoolCode] float,
    [school_name] nvarchar(255),
    [SchoolType] nvarchar(255),
    [Address] nvarchar(255)
);

CREATE TABLE [Load to AU school staging table] (
    [state_code] nvarchar(255),
    [town_suburb] nvarchar(255),
    [postcode] float,
    [school_code] float,
    [school_name] nvarchar(255),
    [SchoolType] nvarchar(255),
    [address] nvarchar(255)
);